
interface StackOperation {
    public void push(int data);
    public void pop();
    public void dislpay();
    public int getTop();
    public int getTopValue();
}