
interface IntOperation {
    boolean positive();
    boolean negative();
    boolean isEven();
    boolean isOdd();
    boolean isPrime();
    int factorial();
    int sum();
}